#!/bin/bash

#docker run --rm -it -i --net=host -p 8000:8000 smag:latest bash 
docker run --rm -it -i --net=host -p 8000:8000 smag:latest 
